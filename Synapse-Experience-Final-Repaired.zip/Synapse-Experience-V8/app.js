// --- CONFIGURATION ---
const APP_CONFIG = {
    phone: "989108381540",
    phoneHref: "+989108381540",
    phoneDisplay: "+98 910 838 1540",
    email: "info.synapse2026@gmail.com",
    telegramUrl: "https://t.me/Synapseai_team",
    telegramHandle: "@Synapseai_team",
    brandName: "Synapse AI Team",
    providerRole: "Interactive Digital Experience Provider"
};

function getPublicOrigin() {
    try {
        if (typeof window !== 'undefined' && window.location && window.location.origin &&
            window.location.protocol !== 'file:') {
            return window.location.origin;
        }
    } catch (_) {}
    return '';
}

const translations = {
    en: {
        nav_programs: "Programs", nav_corporate: "Corporate", nav_experts: "Experts",
        nav_about: "About", nav_contact: "Contact", btn_talk: "Let's Talk", lang_toggle: "العربية",
        hero_tag: "Concept Demo", hero_title1: "Transform Your People.", hero_title2: "Accelerate Your Business.",
        hero_desc: "Premium professional training and corporate learning experiences designed for modern business.",
        btn_explore: "Explore the Experience", btn_proposal: "Request a Proposal", btn_whatsapp: "WhatsApp Us",
        stats_prof: "Professionals Trained", stats_prog: "Programs", stats_org: "Organizations", stats_count: "Countries",
        stats_demo: "Concept Demo — Sample Data",
        journey_title: "What brings you here?", journey_tag: "Smart Journey",
        j_explore: "I want to explore programs", j_corp: "I represent a company", j_prof: "I want professional training", j_expert: "I want to speak with an expert",
        card_ai_tag: "Technology", card_ai_title: "AI & Digital Transformation", card_ai_desc: "Navigate the future of business by leveraging artificial intelligence and digital workflows.",
        card_lead_tag: "Management", card_lead_title: "Leadership Excellence", card_lead_desc: "Equip your executive team with modern leadership frameworks and decision-making strategies.",
        card_sales_tag: "Business", card_sales_title: "Sales & Customer Experience", card_sales_desc: "Drive revenue growth and build lasting customer relationships through advanced methodologies.",
        btn_explore_prog: "Explore Program",
        corp_tag: "Corporate Solutions", corp_title: "Training Built Around Your Business",
        corp_desc: "Customized learning experiences designed around organizational goals, workforce needs and business challenges.",
        corp_list1_t: "Needs Assessment", corp_list1_d: "We analyze your skill gaps before designing content.",
        corp_list2_t: "Program Design", corp_list2_d: "Tailored curriculum reflecting real-world scenarios.",
        corp_list3_t: "Continuous Improvement", corp_list3_d: "Post-training evaluation and ongoing support.",
        val_tag: "Value Proposition", val_title: "Why Organizations Choose Gulf Edge",
        val1_t: "Industry-Focused", val1_d: "Training connected to real business needs, not just academic theory.",
        val2_t: "Expert-Led", val2_d: "Delivered by experienced professionals and practitioners who know the market.",
        val3_t: "International Perspective", val3_d: "Modern learning designed for global business environments with local context.",
        exp_tag: "Our Faculty", exp_title: "Meet Our Experts", btn_view_all: "View All Faculty",
        gal_tag: "The Experience", gal_title: "Inside Gulf Edge",
        biz_tag: "One Experience. Many Industries.", biz_title: "Imagine This for Your Business",
        biz_desc: "This experience can be customized for academies, real estate companies, consultants, hotels, clinics, schools and professional businesses.",
        btn_create_biz: "Create My Business Experience",
        fin_title: "Ready to Elevate Your Business?", fin_desc: "Let's create a digital experience that makes your business easier to discover, understand and contact.",
        fin_msg1: "Your business deserves more than a digital brochure.", fin_msg2: "Give your audience an experience.",
        ft_desc: "Interactive Digital Experience for modern businesses. Premium professional training and corporate learning solutions.",
        ft_ql: "Navigation", ft_contact: "Contact Provider", ft_demo: "Interactive Digital Experience — Concept Demo", ft_copy: "© 2026 Gulf Edge Academy. Interactive Digital Experience — Concept Demo."
    },
    ar: {
        nav_programs: "البرامج", nav_corporate: "الشركات", nav_experts: "الخبراء",
        nav_about: "عن الأكاديمية", nav_contact: "اتصل بنا", btn_talk: "تحدث معنا", lang_toggle: "English",
        hero_tag: "نموذج تجريبي", hero_title1: "طوّر قدرات فريقك.", hero_title2: "سرّع نمو أعمالك.",
        hero_desc: "تجارب تدريب مهني وتعليم مؤسسي متميزة مصممة لمتطلبات الأعمال الحديثة.",
        btn_explore: "استكشف التجربة", btn_proposal: "اطلب عرض سعر", btn_whatsapp: "راسلنا عبر واتساب",
        stats_prof: "متدرب محترف", stats_prog: "برنامج تدريبي", stats_org: "مؤسسة", stats_count: "دولة",
        stats_demo: "نموذج تجريبي — بيانات نموذجية",
        journey_title: "ما الذي تبحث عنه؟", journey_tag: "الرحلة الذكية",
        j_explore: "أريد استكشاف البرامج", j_corp: "أنا أمثل شركة", j_prof: "أبحث عن تدريب مهني", j_expert: "أريد التحدث مع خبير",
        card_ai_tag: "التكنولوجيا", card_ai_title: "الذكاء الاصطناعي والتحول الرقمي", card_ai_desc: "قُد مستقبل أعمالك عبر الاستفادة من الذكاء الاصطناعي وسير العمل الرقمي.",
        card_lead_tag: "الإدارة", card_lead_title: "التميز القيادي", card_lead_desc: "زوّد فريقك التنفيذي بأطر القيادة الحديثة واستراتيجيات اتخاذ القرار.",
        card_sales_tag: "الأعمال", card_sales_title: "المبيعات وتجربة العملاء", card_sales_desc: "عزز نمو الإيرادات وابنِ علاقات دائمة مع العملاء من خلال منهجيات متقدمة.",
        btn_explore_prog: "استكشف البرنامج",
        corp_tag: "حلول الشركات", corp_title: "تدريب مصمم خصيصاً لأعمالك",
        corp_desc: "تجارب تعليمية مخصصة تتمحور حول الأهداف التنظيمية واحتياجات القوى العاملة وتحديات الأعمال.",
        corp_list1_t: "تقييم الاحتياجات", corp_list1_d: "نحلل الفجوات في المهارات قبل تصميم المحتوى.",
        corp_list2_t: "تصميم البرنامج", corp_list2_d: "مناهج مصممة خصيصاً تعكس سيناريوهات العالم الحقيقي.",
        corp_list3_t: "التحسين المستمر", corp_list3_d: "تقييم ما بعد التدريب والدعم المستمر.",
        val_tag: "القيمة المضافة", val_title: "لماذا تختار المؤسسات جلف إيدج",
        val1_t: "تركيز على الصناعة", val1_d: "تدريب مرتبط باحتياجات العمل الحقيقية، وليس مجرد نظريات أكاديمية.",
        val2_t: "بقيادة خبراء", val2_d: "يقدمها محترفون وممارسون ذوو خبرة يعرفون السوق جيداً.",
        val3_t: "منظور دولي", val3_d: "تعليم حديث مصمم لبيئات الأعمال العالمية مع سياق محلي.",
        exp_tag: "هيئة التدريس", exp_title: "تعرف على خبرائنا", btn_view_all: "عرض جميع الخبراء",
        gal_tag: "التجربة", gal_title: "داخل جلف إيدج",
        biz_tag: "تجربة واحدة. مجالات متعددة.", biz_title: "تخيل هذا لعملك",
        biz_desc: "يمكن تخصيص هذه التجربة للأكاديميات، الشركات العقارية، الاستشاريين، الفنادق، العيادات، المدارس والأعمال المهنية.",
        btn_create_biz: "اصنع تجربة عملي",
        fin_title: "هل أنت مستعد للارتقاء بعملك؟", fin_desc: "دعنا نصنع تجربة رقمية تجعل اكتشاف وفهم والاتصال بعملك أسهل.",
        fin_msg1: "عملك يستحق أكثر من مجرد كتيب رقمي.", fin_msg2: "امنح جمهورك تجربة استثنائية.",
        ft_desc: "تجربة رقمية تفاعلية للأعمال الحديثة. حلول تدريب مهني وتعليم مؤسسي متميزة.",
        ft_ql: "التنقل", ft_contact: "اتصل بمزود الخدمة", ft_demo: "نموذج تجريبي — بيانات المزود", ft_copy: "© 2026 جلف إيدج. تجربة رقمية تفاعلية — نموذج تجريبي."
    }
};

let currentLang = localStorage.getItem('gulf_lang') || 'en';
let openModalCount = 0;

function lockBodyScroll() {
    openModalCount++;
    document.body.style.overflow = 'hidden';
}
function unlockBodyScroll() {
    openModalCount = Math.max(0, openModalCount - 1);
    if (openModalCount === 0) document.body.style.overflow = '';
}

document.addEventListener('DOMContentLoaded', () => {

    // Inject configs dynamically
    document.querySelectorAll('[data-config]').forEach(el => {
        const confKey = el.getAttribute('data-config');
        if (APP_CONFIG[confKey] != null) {
            if (el.tagName === 'A' && el.getAttribute('href') === 'tel:') {
                el.setAttribute('href', `tel:${APP_CONFIG[confKey]}`);
            } else if (el.tagName === 'A' && el.getAttribute('href') === 'mailto:') {
                el.setAttribute('href', `mailto:${APP_CONFIG[confKey]}`);
            } else if (el.tagName === 'A' && !el.hasAttribute('href')) {
                el.setAttribute('href', APP_CONFIG[confKey]);
            } else {
                el.textContent = APP_CONFIG[confKey];
            }
        }
    });

    // Fix Telegram links that were left incomplete
    document.querySelectorAll('a[href="https://t.me/"], a[href="https://t.me"]').forEach(a => {
        a.setAttribute('href', APP_CONFIG.telegramUrl);
    });

    // QR uses current origin (never hardcoded temporary domain)
    const qrImg = document.getElementById('qr-code-img');
    if (qrImg) {
        const origin = getPublicOrigin() || window.location.href.split('#')[0];
        qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(origin)}`;
        qrImg.onerror = function () {
            this.onerror = null;
            this.alt = 'QR unavailable';
            this.style.display = 'none';
        };
    }

    applyLanguage(currentLang);

    // --- Core UI & Navbar ---
    const navbar = document.getElementById('navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('bg-black/90', 'backdrop-blur-xl', 'border-b', 'border-white/10');
                navbar.classList.remove('py-4');
                navbar.classList.add('py-2');
            } else {
                navbar.classList.remove('bg-black/90', 'backdrop-blur-xl', 'border-b', 'border-white/10');
                navbar.classList.add('py-4');
                navbar.classList.remove('py-2');
            }
        }, { passive: true });
    }

    // Smooth scroll for anchors
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (!targetId || targetId === '#') return;
            const targetEl = document.querySelector(targetId);
            if (targetEl) {
                e.preventDefault();
                const offset = 80;
                const elementPosition = targetEl.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - offset;
                window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
            }
        });
    });

    // --- Language Switcher ---
    const langToggleBtn = document.getElementById('lang-toggle');
    const langToggleMobileBtn = document.getElementById('lang-toggle-mobile');

    function toggleLanguage() {
        currentLang = currentLang === 'en' ? 'ar' : 'en';
        localStorage.setItem('gulf_lang', currentLang);
        applyLanguage(currentLang);
    }

    if (langToggleBtn) langToggleBtn.addEventListener('click', toggleLanguage);
    if (langToggleMobileBtn) langToggleMobileBtn.addEventListener('click', toggleLanguage);

    function applyLanguage(lang) {
        document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
        document.documentElement.setAttribute('lang', lang);
        // body dir for CSS selectors that use body[dir]
        document.body.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (translations[lang] && translations[lang][key]) {
                el.textContent = translations[lang][key];
            }
        });
        if (langToggleBtn) langToggleBtn.textContent = lang === 'en' ? 'العربية' : 'English';
        if (langToggleMobileBtn) langToggleMobileBtn.textContent = lang === 'en' ? 'العربية' : 'English';
    }
    window.applyLanguage = applyLanguage;

    // --- Scroll Reveal ---
    const revealElements = document.querySelectorAll('.reveal-on-scroll');
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (!prefersReducedMotion) {
        const revealObserver = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    obs.unobserve(entry.target);
                }
            });
        }, { root: null, threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
        revealElements.forEach(el => revealObserver.observe(el));
    } else {
        revealElements.forEach(el => el.classList.add('is-visible'));
    }

    // --- Parallax Effect (desktop only, reduced-motion off) ---
    if (!prefersReducedMotion && window.innerWidth > 768) {
        window.addEventListener('scroll', () => {
            const scrolled = window.scrollY;
            document.querySelectorAll('.parallax-img').forEach(el => {
                el.style.transform = `translateY(${scrolled * 0.15}px)`;
            });
            document.querySelectorAll('.parallax-element').forEach(el => {
                el.style.transform = `translateY(${scrolled * -0.1}px)`;
            });
        }, { passive: true });
    }

    // --- Smart Journey Filtering ---
    const filterBtns = document.querySelectorAll('#journey-filters button');
    const programCards = document.querySelectorAll('.program-card');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => {
                b.classList.remove('border-yellow-500', 'text-yellow-500');
                b.classList.add('border-white/10', 'text-gray-300');
            });
            btn.classList.add('border-yellow-500', 'text-yellow-500');
            btn.classList.remove('border-white/10', 'text-gray-300');
            const target = btn.getAttribute('data-target');
            programCards.forEach(card => {
                const categories = (card.getAttribute('data-category') || '').split(' ');
                if (target === 'all' || categories.includes(target)) {
                    card.style.display = 'flex';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'scale(1)';
                    }, 50);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'scale(0.95)';
                    setTimeout(() => { card.style.display = 'none'; }, 300);
                }
            });
            if (target === 'expert') openModal('contact-hub-modal');
        });
    });

    // --- Modals Logic ---
    window.openModal = function (id) {
        const modal = document.getElementById(id);
        if (!modal) return;
        if (!modal.classList.contains('active')) {
            modal.classList.add('active');
            lockBodyScroll();
            const focusable = modal.querySelectorAll(
                'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
            );
            if (focusable.length) {
                try { focusable[0].focus(); } catch (_) {}
            }
        }
    };

    window.closeModal = function (id) {
        const modal = document.getElementById(id);
        if (!modal) return;
        if (modal.classList.contains('active')) {
            modal.classList.remove('active');
            unlockBodyScroll();
        }
    };

    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeModal(overlay.id);
        });
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.active').forEach(m => closeModal(m.id));
            const lb = document.getElementById('lightbox');
            if (lb && lb.classList.contains('active')) {
                lb.classList.remove('active');
                unlockBodyScroll();
            }
        }
    });

    window.openProgramModal = function (title, category, img) {
        const titleEl = document.getElementById('program-modal-title');
        const tagEl = document.getElementById('program-modal-tag');
        const imgEl = document.getElementById('program-modal-img');
        if (titleEl) titleEl.textContent = title || '';
        if (tagEl) tagEl.textContent = category || '';
        if (imgEl) {
            imgEl.src = img || '';
            imgEl.alt = title || 'Program';
        }
        openModal('program-modal');
    };

    // --- Multi-step Form Logic ---
    let currentStep = 1;

    window.nextStep = function (step) {
        const prev = document.getElementById(`step-${currentStep}`);
        if (prev) prev.classList.remove('active');
        // also hide success/error when navigating back
        const success = document.getElementById('step-success');
        const error = document.getElementById('step-error');
        if (success) success.classList.remove('active');
        if (error) error.classList.remove('active');
        currentStep = step;
        const next = document.getElementById(`step-${currentStep}`);
        if (next) next.classList.add('active');
    };

    window.submitProposal = async function (e) {
        e.preventDefault();
        const form = e.target;
        if (!form) return;

        const honey = form.querySelector('[name="_honey"]');
        if (honey && honey.value) return;

        const nameInput = form.querySelector('[name="name"]');
        const companyInput = form.querySelector('[name="company"]');
        const emailInput = form.querySelector('[name="email"]');
        const phoneInput = form.querySelector('[name="phone"]');
        const goalsInput = form.querySelector('[name="goals"]');
        const needChecked = form.querySelector('input[name="need"]:checked');
        const contactChecked = form.querySelector('input[name="contact"]:checked');

        const name = nameInput ? nameInput.value.trim() : '';
        const email = emailInput ? emailInput.value.trim() : '';
        const need = needChecked ? needChecked.value : '';
        const contact = contactChecked ? contactChecked.value : '';

        if (!name || !email || !need || !contact) {
            if (!need || !contact) {
                // Move to step that needs attention if possible
                if (!need) nextStep(2);
                else nextStep(3);
            }
            return;
        }

        const submitBtn = document.getElementById('form-submit-btn');
        const originalBtnHtml = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
            submitBtn.innerHTML = `<i class="ph-bold ph-spinner animate-spin"></i> Sending...`;
            submitBtn.disabled = true;
        }

        const data = {
            name: name,
            company: companyInput ? companyInput.value.trim() : '',
            email: email,
            phone: phoneInput ? phoneInput.value.trim() : '',
            need: need,
            goals: goalsInput ? goalsInput.value.trim() : '',
            contact: contact,
            _honey: honey ? honey.value : ''
        };

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 20000);

        try {
            const res = await fetch('/api/contact', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            let payload = null;
            try {
                payload = await res.json();
            } catch (_) {
                payload = null;
            }

            const ok = res.ok && payload && payload.success === true;

            const stepEl = document.getElementById(`step-${currentStep}`);
            if (stepEl) stepEl.classList.remove('active');

            if (ok) {
                const successEl = document.getElementById('step-success');
                if (successEl) successEl.classList.add('active');
            } else {
                const errorEl = document.getElementById('step-error');
                if (errorEl) errorEl.classList.add('active');
            }
        } catch (err) {
            clearTimeout(timeoutId);
            const stepEl = document.getElementById(`step-${currentStep}`);
            if (stepEl) stepEl.classList.remove('active');
            const errorEl = document.getElementById('step-error');
            if (errorEl) errorEl.classList.add('active');
        } finally {
            if (submitBtn) {
                submitBtn.innerHTML = originalBtnHtml || `Submit Request <i class="ph-bold ph-paper-plane-tilt"></i>`;
                submitBtn.disabled = false;
            }
        }
    };

    // --- Lightbox Gallery ---
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    if (lightbox && lightboxImg) {
        document.querySelectorAll('.gallery-img').forEach(img => {
            img.addEventListener('click', (e) => {
                e.preventDefault();
                lightboxImg.src = img.src;
                lightboxImg.alt = img.alt || 'Gallery image';
                if (!lightbox.classList.contains('active')) {
                    lightbox.classList.add('active');
                    lockBodyScroll();
                }
            });
            img.style.cursor = 'pointer';
        });
        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox || e.target === lightboxImg) {
                lightbox.classList.remove('active');
                unlockBodyScroll();
            }
        });
        const lbClose = lightbox.querySelector('button');
        if (lbClose) {
            lbClose.addEventListener('click', () => {
                lightbox.classList.remove('active');
                unlockBodyScroll();
            });
        }
    }

    // --- Dynamic WhatsApp CTA ---
    window.openContextWA = function (context) {
        const phone = APP_CONFIG.phone;
        let msg = 'Hello, I would like to learn more about creating an interactive digital experience for my business.';
        if (context === 'training') msg = 'Hello, I would like to learn more about the training experience shown in the demo.';
        if (context === 'corporate') msg = 'Hello, I am interested in creating a digital experience for my company.';
        if (context === 'real_estate') msg = 'Hello, I am interested in creating an interactive digital experience for my real estate business.';
        if (context === 'program') {
            const titleEl = document.getElementById('program-modal-title');
            const title = titleEl ? titleEl.textContent : 'program';
            msg = `Hello, I would like more information about the ${title} experience.`;
        }
        window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener,noreferrer');
    };

    // --- Dynamic Email ---
    window.openContextEmail = function (context) {
        const email = APP_CONFIG.email;
        let subj = 'Interactive Digital Experience Inquiry';
        if (context === 'corporate') subj = 'Corporate Digital Experience Inquiry';
        if (context === 'real_estate') subj = 'Real Estate Experience Inquiry';
        if (context === 'meeting') subj = 'Meeting Request — Gulf Edge Academy';
        window.location.href = `mailto:${email}?subject=${encodeURIComponent(subj)}`;
    };

    // --- vCard Generator ---
    window.downloadVCard = function () {
        const escapeVCard = (v) => String(v || '').replace(/[\\,;]/g, (c) => '\\' + c);
        const lines = [
            'BEGIN:VCARD',
            'VERSION:3.0',
            `FN:${escapeVCard(APP_CONFIG.brandName)}`,
            `ORG:${escapeVCard(APP_CONFIG.providerRole)}`,
            `TEL;TYPE=CELL:${escapeVCard(APP_CONFIG.phoneHref)}`,
            `EMAIL:${escapeVCard(APP_CONFIG.email)}`,
            `URL:${escapeVCard(APP_CONFIG.telegramUrl)}`,
            'END:VCARD'
        ];
        const vcard = lines.join('\r\n');
        const blob = new Blob([vcard], { type: 'text/vcard;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Synapse_AI_Contact.vcf';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    // --- Share API ---
    window.shareExperience = function () {
        const url = getPublicOrigin() || window.location.href.split('#')[0];
        if (navigator.share) {
            navigator.share({
                title: 'Gulf Edge Academy',
                text: 'Check out this Interactive Digital Experience Demo',
                url: url
            }).catch(() => {});
        } else if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(() => {
                alert('Link copied to clipboard!');
            }).catch(() => {
                prompt('Copy this link:', url);
            });
        } else {
            prompt('Copy this link:', url);
        }
    };

    // --- Mobile Menu Toggle ---
    window.toggleMobileMenu = function () {
        const menu = document.getElementById('mobile-menu');
        if (!menu) return;
        const isHidden = menu.classList.contains('hidden');
        if (isHidden) {
            menu.classList.remove('hidden');
            menu.classList.add('flex');
            lockBodyScroll();
        } else {
            menu.classList.add('hidden');
            menu.classList.remove('flex');
            unlockBodyScroll();
        }
    };

    // Close mobile menu after nav link click is already handled via onclick in HTML

    // --- Service Worker & PWA Registration ---
    let deferredPrompt = null;
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        const installBtn = document.getElementById('pwa-install-btn');
        if (installBtn) installBtn.style.display = 'block';
    });

    window.installPWA = async function () {
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        try {
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') deferredPrompt = null;
        } catch (_) {}
        const installBtn = document.getElementById('pwa-install-btn');
        if (installBtn) installBtn.style.display = 'none';
    };

    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js').catch(() => {});
        });
    }
});
