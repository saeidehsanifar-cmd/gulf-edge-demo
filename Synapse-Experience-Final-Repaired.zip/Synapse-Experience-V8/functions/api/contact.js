/**
 * Cloudflare Pages Function — POST /api/contact
 * Production email handler for Gulf Edge Academy / Synapse Experience.
 *
 * Required environment variables (Cloudflare Pages → Settings → Environment variables):
 *   EMAIL_API_KEY  — Resend (or compatible) API key (Secret)
 *   EMAIL_FROM     — Verified sender, e.g. "Gulf Edge <noreply@yourdomain.com>"
 *   EMAIL_TO       — Recipient, e.g. "info.synapse2026@gmail.com"
 *   SITE_URL       — Public HTTPS origin, e.g. "https://your-project.pages.dev"
 */

const ALLOWED_NEEDS = new Set([
  'Interactive Digital Experience',
  'Corporate Training',
  'Real Estate Experience',
  'Consulting',
]);

const ALLOWED_CONTACTS = new Set(['WhatsApp', 'Phone', 'Email', 'Telegram']);

const MAX_LEN = {
  name: 120,
  company: 160,
  email: 254,
  phone: 40,
  need: 80,
  goals: 4000,
  contact: 40,
};

function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isValidEmail(email) {
  if (typeof email !== 'string') return false;
  const e = email.trim();
  if (e.length < 5 || e.length > MAX_LEN.email) return false;
  // Practical RFC-ish check; not overly strict for international addresses
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
}

function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
    },
  });
}

export async function onRequest(context) {
  const { request, env } = context;

  if (request.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Max-Age': '86400',
      },
    });
  }

  if (request.method !== 'POST') {
    return jsonResponse({ success: false, message: 'Method not allowed.' }, 405);
  }

  const contentType = request.headers.get('Content-Type') || '';
  if (!contentType.includes('application/json')) {
    return jsonResponse({ success: false, message: 'Expected application/json.' }, 415);
  }

  let data;
  try {
    const text = await request.text();
    if (text.length > 32_000) {
      return jsonResponse({ success: false, message: 'Payload too large.' }, 413);
    }
    data = JSON.parse(text);
  } catch {
    return jsonResponse({ success: false, message: 'Invalid JSON body.' }, 400);
  }

  if (!data || typeof data !== 'object') {
    return jsonResponse({ success: false, message: 'Invalid payload.' }, 400);
  }

  // Honeypot — reject silently-ish (no email, no success)
  if (data._honey != null && String(data._honey).trim().length > 0) {
    return jsonResponse({ success: false, message: 'Unable to process request.' }, 403);
  }

  const name = String(data.name || '').trim();
  const company = String(data.company || '').trim();
  const email = String(data.email || '').trim();
  const phone = String(data.phone || '').trim();
  const need = String(data.need || '').trim();
  const goals = String(data.goals || '').trim();
  const contact = String(data.contact || '').trim();

  if (!name || name.length > MAX_LEN.name) {
    return jsonResponse({ success: false, message: 'Valid name is required.' }, 400);
  }
  if (!isValidEmail(email)) {
    return jsonResponse({ success: false, message: 'Valid email is required.' }, 400);
  }
  if (!need || !ALLOWED_NEEDS.has(need) || need.length > MAX_LEN.need) {
    return jsonResponse({ success: false, message: 'Valid interest is required.' }, 400);
  }
  if (!contact || !ALLOWED_CONTACTS.has(contact) || contact.length > MAX_LEN.contact) {
    return jsonResponse({ success: false, message: 'Valid preferred contact method is required.' }, 400);
  }
  if (company.length > MAX_LEN.company) {
    return jsonResponse({ success: false, message: 'Company name is too long.' }, 400);
  }
  if (goals.length > MAX_LEN.goals) {
    return jsonResponse({ success: false, message: 'Message is too long.' }, 400);
  }
  if (phone.length > MAX_LEN.phone) {
    return jsonResponse({ success: false, message: 'Phone number is too long.' }, 400);
  }

  const apiKey = env.EMAIL_API_KEY;
  const emailFrom = env.EMAIL_FROM;
  const emailTo = env.EMAIL_TO || 'info.synapse2026@gmail.com';
  const siteUrl = (env.SITE_URL || '').replace(/\/$/, '');

  if (!apiKey || !emailFrom) {
    console.error('EMAIL_API_KEY or EMAIL_FROM missing in environment.');
    return jsonResponse(
      {
        success: false,
        message: 'Email service is not configured. Please contact us via WhatsApp or email.',
      },
      503
    );
  }

  if (!siteUrl || !/^https:\/\//i.test(siteUrl)) {
    console.error('SITE_URL missing or not HTTPS.');
    return jsonResponse(
      {
        success: false,
        message: 'Site configuration incomplete. Please contact us via WhatsApp or email.',
      },
      503
    );
  }

  const logoUrl = `${siteUrl}/assets/images/synapse-logo.png`;
  const safeName = escapeHtml(name);
  const safeCompany = escapeHtml(company || 'N/A');
  const safeEmail = escapeHtml(email);
  const safePhone = escapeHtml(phone || 'N/A');
  const safeNeed = escapeHtml(need);
  const safeContact = escapeHtml(contact);
  const safeGoals = goals
    ? escapeHtml(goals).replace(/\r\n|\r|\n/g, '<br>')
    : 'No specific message provided.';
  const timestamp = new Date().toISOString();

  const htmlEmail = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>New Inquiry — Gulf Edge Academy</title>
</head>
<body style="font-family: Arial, Helvetica, sans-serif; background-color: #0A0A0C; color: #ffffff; padding: 20px; margin: 0;">
  <div style="max-width: 600px; margin: 0 auto; background-color: #121215; border: 1px solid #333; border-radius: 12px; overflow: hidden;">
    <div style="padding: 30px; text-align: center; border-bottom: 1px solid #333; background-color: #050505;">
      <img src="${logoUrl}" alt="Synapse" style="max-height: 72px; width: auto; margin-bottom: 16px;">
      <h1 style="color: #D4AF37; margin: 0; font-size: 22px; text-transform: uppercase; letter-spacing: 2px;">Gulf Edge Academy</h1>
      <p style="color: #A0A0A5; margin: 8px 0 0 0; font-size: 14px;">New Interactive Experience Inquiry</p>
    </div>
    <div style="padding: 30px;">
      <h2 style="font-size: 16px; color: #ffffff; margin: 0 0 16px 0; border-bottom: 1px solid #333; padding-bottom: 10px;">Lead Information</h2>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px;">
        <tr>
          <td style="padding: 8px 0; color: #A0A0A5; font-size: 14px; width: 40%;">Name</td>
          <td style="padding: 8px 0; color: #ffffff; font-size: 14px; font-weight: bold;">${safeName}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #A0A0A5; font-size: 14px;">Company</td>
          <td style="padding: 8px 0; color: #ffffff; font-size: 14px; font-weight: bold;">${safeCompany}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #A0A0A5; font-size: 14px;">Email</td>
          <td style="padding: 8px 0; color: #ffffff; font-size: 14px; font-weight: bold;">
            <a href="mailto:${safeEmail}" style="color: #00E5FF; text-decoration: none;">${safeEmail}</a>
          </td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #A0A0A5; font-size: 14px;">Phone</td>
          <td style="padding: 8px 0; color: #ffffff; font-size: 14px; font-weight: bold;">${safePhone}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #A0A0A5; font-size: 14px;">Interest</td>
          <td style="padding: 8px 0; color: #D4AF37; font-size: 14px; font-weight: bold;">${safeNeed}</td>
        </tr>
        <tr>
          <td style="padding: 8px 0; color: #A0A0A5; font-size: 14px;">Preferred Contact</td>
          <td style="padding: 8px 0; color: #ffffff; font-size: 14px; font-weight: bold;">${safeContact}</td>
        </tr>
      </table>
      <h2 style="font-size: 16px; color: #ffffff; margin: 0 0 12px 0; border-bottom: 1px solid #333; padding-bottom: 10px;">Message / Goals</h2>
      <div style="background-color: #0A0A0C; padding: 16px; border-radius: 8px; color: #EFEFEF; font-size: 14px; line-height: 1.6;">
        ${safeGoals}
      </div>
    </div>
    <div style="padding: 20px 30px; background-color: #050505; border-top: 1px solid #333; text-align: center;">
      <a href="mailto:${safeEmail}" style="display: inline-block; padding: 12px 24px; background-color: #D4AF37; color: #000000; text-decoration: none; font-weight: bold; border-radius: 6px; font-size: 14px;">Contact Lead</a>
      <p style="color: #666666; font-size: 12px; margin-top: 20px; margin-bottom: 0;">
        Source: Gulf Edge Academy Interactive Demo<br>${escapeHtml(timestamp)}
      </p>
    </div>
  </div>
</body>
</html>`;

  try {
    const emailRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: emailFrom,
        to: [emailTo],
        subject: `New ${need} Inquiry — Gulf Edge Academy`,
        html: htmlEmail,
        reply_to: email,
      }),
    });

    if (!emailRes.ok) {
      const errText = await emailRes.text().catch(() => '');
      console.error('Email provider error:', emailRes.status, errText.slice(0, 500));
      return jsonResponse(
        {
          success: false,
          message: 'Unable to send your request right now. Please try WhatsApp or email instead.',
        },
        502
      );
    }

    return jsonResponse({
      success: true,
      message: 'Request successfully processed and submitted.',
    });
  } catch (err) {
    console.error('API Error:', err && err.message ? err.message : err);
    return jsonResponse(
      {
        success: false,
        message: 'An internal error occurred while processing the request.',
      },
      500
    );
  }
}
