import os
import re
from PIL import Image

# 1. OPTIMIZE IMAGES (STANDARD JPEG/PNG TO ENSURE 100% MOBILE COMPATIBILITY)
img_dir = "assets/images"
for filename in os.listdir(img_dir):
    filepath = os.path.join(img_dir, filename)
    try:
        img = Image.open(filepath)
        
        if filepath.lower().endswith(('.jpg', '.jpeg', '.jfif')):
            if img.mode != 'RGB':
                img = img.convert('RGB')
            # Resize
            max_width = 1024
            if img.width > max_width:
                ratio = max_width / float(img.width)
                new_height = int(float(img.height) * float(ratio))
                img = img.resize((max_width, new_height), Image.Resampling.LANCZOS)
            # Save standard JPEG
            img.save(filepath, format="JPEG", quality=80, optimize=True)
            
        elif filepath.lower().endswith('.png'):
            max_width = 600
            if img.width > max_width:
                ratio = max_width / float(img.width)
                new_height = int(float(img.height) * float(ratio))
                img = img.resize((max_width, new_height), Image.Resampling.LANCZOS)
            img.save(filepath, format="PNG", optimize=True)
            
    except Exception as e:
        print(f"Error optimizing {filepath}: {e}")

# 2. FIX HTML
with open("index.html", "r", encoding="utf-8") as f:
    html = f.read()

# Hardcode Phone Number in HTML
html = html.replace('href="https://wa.me/"', 'href="https://wa.me/989108381540"')
html = html.replace('href="tel:"', 'href="tel:+989108381540"')
html = html.replace('>Phone<', '>+98 910 838 1540<')

# Remove data-config to prevent JS from overriding the hardcoded HTML values
html = re.sub(r'data-config="[^"]+"', '', html)

# Replace Brand Name
html = html.replace('GULF EDGE ACADEMY', 'SYNAPSE AI')
html = html.replace('GULF EDGE', 'SYNAPSE')
html = html.replace('Gulf Edge', 'Synapse AI')

# Replace Logo
html = html.replace(
    '<div class="w-8 h-8 rounded-sm bg-yellow-500 flex items-center justify-center text-black font-bold text-sm">GE</div>',
    '<img src="assets/images/synapse-logo.png" alt="Synapse Logo" class="h-10 w-auto object-contain">'
)
html = html.replace(
    '<div class="w-10 h-10 rounded bg-yellow-500 flex items-center justify-center text-black font-bold text-lg">GE</div>',
    '<img src="assets/images/synapse-logo.png" alt="Synapse Logo" class="h-16 w-auto object-contain mb-2">'
)

# Fix Mobile Clipping Issues
html = html.replace('h-40 mb-6 rounded-xl', 'aspect-video w-full mb-6 rounded-xl')
html = html.replace('h-[400px]', 'aspect-[3/4] w-full h-auto')

# Remove <picture> tags to ensure straight loading via <img> tag on mobile
html = re.sub(r'<picture>\s*<source[^>]+>\s*(<img[^>]+>)\s*</picture>', r'\1', html)

with open("index.html", "w", encoding="utf-8") as f:
    f.write(html)

# 3. FIX JS
with open("app.js", "r", encoding="utf-8") as f:
    js = f.read()

js = js.replace('phone: "989108381540"', 'phone: "989108381540"')
js = js.replace('phoneHref: "+989108381540"', 'phoneHref: "+989108381540"')
js = js.replace('const logoUrl = `${siteUrl}/assets/images/synapse-logo.png`;', 'const logoUrl = `${siteUrl}/assets/images/synapse-logo.png`;')

with open("app.js", "w", encoding="utf-8") as f:
    f.write(js)

print("HTML, JS, and Image Optimization Complete.")
