import os
import re
from PIL import Image

img_dir = "assets/images"

for filename in os.listdir(img_dir):
    filepath = os.path.join(img_dir, filename)
    try:
        img = Image.open(filepath)
        
        # WE MUST CONVERT TO STANDARD JPEG/RGB FOR 100% COMPATIBILITY
        if img.mode != 'RGB':
            if img.mode in ('RGBA', 'LA', 'P'):
                bg = Image.new("RGB", img.size, (255, 255, 255))
                bg.paste(img, mask=img.split()[3] if img.mode == 'RGBA' else img.split()[1] if img.mode == 'LA' else None)
                img = bg
            else:
                img = img.convert('RGB')
        
        # Max resolution for Mobile/Desktop Performance
        max_width = 1200 if 'hero' in filename else 800
        if img.width > max_width:
            ratio = max_width / float(img.width)
            new_height = int(float(img.height) * float(ratio))
            img = img.resize((max_width, new_height), Image.Resampling.LANCZOS)
            
        # SAVE OVER EXISTING IMAGE as standard progressive JPEG
        img.save(filepath, format="JPEG", quality=85, optimize=True, progressive=True)
    except Exception as e:
        print(f"Error converting {filename}: {e}")

# FIX HTML References
with open("index.html", "r", encoding="utf-8") as f:
    html = f.read()

# Replace images mapping correctly based on new files
html = html.replace('assets/images/ai-intelligence.jpg', 'assets/images/fubo-office.jpg')
html = html.replace('assets/images/cityscape.jpg', 'assets/images/dubai-business.jpg')
html = html.replace('assets/images/luxury-office.jpg', 'assets/images/office-white.jpg')
html = html.replace('assets/images/dubai-cityscape.jpg', 'assets/images/dubai-dreams.jpg')

with open("index.html", "w", encoding="utf-8") as f:
    f.write(html)
