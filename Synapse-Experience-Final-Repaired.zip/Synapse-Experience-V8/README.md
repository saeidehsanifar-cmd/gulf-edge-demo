# Gulf Edge Academy — Interactive Digital Experience

Premium concept demo for Gulf Edge Academy / Synapse AI Team.  
Designed for **Cloudflare Pages** + **Cloudflare Pages Functions**.

## Repository structure

```
Synapse-Experience-Final/
├── index.html
├── app.js
├── styles.css
├── manifest.json
├── sw.js
├── README.md
├── assets/
│   └── images/
│       ├── synapse-logo.png
│       ├── hero.jpg
│       └── … (all project images)
└── functions/
    └── api/
        └── contact.js
```

`fix_v7.py` and `fix_v8.py` are historical repair scripts only.  
They are **not** required at runtime and must not be referenced by the site.

## Cloudflare Pages deployment

1. Push this repository to GitHub.
2. In Cloudflare Dashboard → **Workers & Pages** → **Create** → **Pages** → Connect to Git.
3. Select the repository and branch (`main`).
4. Build settings:
   - **Framework preset:** None
   - **Build command:** *(leave empty)*
   - **Build output directory:** `/` (repository root)
5. After the first deploy, open **Settings → Environment variables** and add the variables below for **Production** (and Preview if desired).
6. Redeploy so Functions pick up the secrets.

### Environment variables (required)

| Variable        | Type   | Description |
|-----------------|--------|-------------|
| `EMAIL_API_KEY` | Secret | Resend API key (`re_…`). Never commit this. |
| `EMAIL_FROM`    | Plain  | Verified sender, e.g. `Gulf Edge <noreply@your-verified-domain.com>` |
| `EMAIL_TO`      | Plain  | Recipient inbox, e.g. `info.synapse2026@gmail.com` |
| `SITE_URL`      | Plain  | Public HTTPS origin of this deployment, e.g. `https://your-project.pages.dev` |

**Important**

- `EMAIL_FROM` **must** use a domain verified with your email provider (Resend).  
  Do **not** use `demo@gulfedge.pages.dev` unless that domain is verified.
- If `EMAIL_API_KEY` or `EMAIL_FROM` is missing, the API returns a **failure** response (never simulated success).
- Frontend same-origin links and QR codes use `window.location.origin` automatically.  
  `SITE_URL` is used only server-side (email logo URL).

## Contact API

- Endpoint: `POST /api/contact`
- Implementation: `functions/api/contact.js`
- Validates JSON, honeypot, length limits, interest and contact method allow-lists.
- Sanitizes all user fields before embedding in HTML email.
- Sends via Resend REST API.
- Never exposes secrets or stack traces to the client.

## Local preview

Serve the static root over HTTP (do not open `file://`):

```bash
npx --yes serve -l 8787 .
# or: python3 -m http.server 8787
```

Cloudflare Functions are not available with a plain static server.  
Form submission will correctly show the **error** state until deployed with env vars configured.

## Features preserved

- Premium dark / gold aesthetic, glassmorphism, parallax (desktop)
- Smart Journey filters, program modals, gallery lightbox
- Contact hub, proposal multi-step form, QR, share, vCard
- English / Arabic + RTL
- PWA manifest + production-safe service worker
- Mobile action bar with safe-area insets

## Concept demo disclosure

Metrics and sample content are for demonstration only and are labeled as concept demo / sample data.
